-- Create database
CREATE DATABASE IF NOT EXISTS myProject;

-- Use the database
USE myProject;

-- Create tables
CREATE TABLE categories (
    id INT PRIMARY KEY,
    category_name VARCHAR(255) NOT NULL
);

CREATE TABLE products (
    id INT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    category_id INT,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE users (
    id INT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL
);

CREATE TABLE orders (
    id INT PRIMARY KEY,
    user_id INT,
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE order_items (
    order_id INT,
    product_id INT,
    quantity INT,
    PRIMARY KEY (order_id, product_id),
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Insert categories
INSERT INTO categories (id, category_name) VALUES (1, 'Bread');
INSERT INTO categories (id, category_name) VALUES (2, 'Cake');
INSERT INTO categories (id, category_name) VALUES (3, 'Pastries');

-- Insert sample data
INSERT INTO products (id, product_name, price, category_id) VALUES (1, 'Baguette', 2.99, 1);
INSERT INTO products (id, product_name, price, category_id) VALUES (2, 'Chocolate Cake', 19.99, 2);
INSERT INTO products (id, product_name, price, category_id) VALUES (3, 'Croissant', 1.99, 3);

INSERT INTO users (id, username, email) VALUES (1, 'john_doe', 'john@example.com');

INSERT INTO orders (id, user_id) VALUES (1, 1);

INSERT INTO order_items (order_id, product_id, quantity) VALUES (1, 1, 2);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (1, 2, 1);
INSERT INTO order_items (order_id, product_id, quantity) VALUES (1, 3, 5);
