document.addEventListener("DOMContentLoaded", () => {
    // Smooth scrolling for navigation links
    document.querySelectorAll('nav a').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            document.getElementById(targetId).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Form validation for Data Collection form
    const dataCollectionForm = document.getElementById('data-collection-form');
    if (dataCollectionForm) {
        dataCollectionForm.addEventListener('submit', function (e) {
            e.preventDefault();
            if (validateForm(dataCollectionForm)) {
                alert('Patient data submitted successfully!');
                // Save patient data to localStorage (or send to server)
                savePatientData();
                dataCollectionForm.reset();
            }
        });
    }

    // Form validation for Contact form
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function (e) {
            e.preventDefault();
            if (validateForm(contactForm)) {
                alert('Message sent successfully!');
                contactForm.reset();
            }
        });
    }

    // Form validation function
    function validateForm(form) {
        let isValid = true;
        const inputs = form.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            if (!input.checkValidity()) {
                input.classList.add('invalid');
                isValid = false;
            } else {
                input.classList.remove('invalid');
            }
        });
        return isValid;
    }

    // Save patient data to localStorage
    function savePatientData() {
        const patientData = {
            name: document.getElementById('name').value,
            dob: document.getElementById('dob').value,
            gender: document.getElementById('gender').value,
            medicalHistory: document.getElementById('medical-history').value,
            treatmentRecords: document.getElementById('treatment-records').value,
            paymentMethod: document.getElementById('payment-method').value,
            paymentDetails: document.getElementById('payment-details').value
        };
        localStorage.setItem(patientData.name, JSON.stringify(patientData));
    }

    // Get patient data from localStorage
    const getPatientForm = document.getElementById('get-patient-form');
    if (getPatientForm) {
        getPatientForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const patientName = document.getElementById('patient-name').value;
            const patientData = JSON.parse(localStorage.getItem(patientName));
            if (patientData) {
                displayPatientData(patientData);
            } else {
                alert('Patient not found!');
            }
        });
    }

    // Display patient data
    function displayPatientData(data) {
        document.getElementById('info-name').textContent = data.name;
        document.getElementById('info-dob').textContent = data.dob;
        document.getElementById('info-gender').textContent = data.gender;
        document.getElementById('info-medical-history').textContent = data.medicalHistory;
        document.getElementById('info-treatment-records').textContent = data.treatmentRecords;
        document.getElementById('info-payment-details').textContent = data.paymentDetails;
        document.getElementById('patient-info').style.display = 'block';
    }
});
