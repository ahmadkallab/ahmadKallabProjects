package btecvehiclesearchTask2;

public class CarReport {

    private String name;
    private int year;
    private String VIN;
    private int vehicleAssessment;
    private boolean issues;

    public CarReport(String name, int year, String VIN, int vehicleAssessment, boolean issues) {
        setIssues(issues);
        setName(name);
        setVIN(VIN);
        setVehicleAssessment(vehicleAssessment);
        setYear(year);
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getYear() {
        return year;
    }

    public void setVIN(String VIN) {
        if (VIN.length() == 17 && VIN.matches("[A-Z0-9&&\\D[^\\s]]+")) {
            this.VIN = VIN;
        } else {
            System.out.println("Invalid VIN. Please enter a valid 17-character VIN without spaces all Uppercase.");
        }
    }

    public String getVIN() {
        return VIN;
    }

   public void setVehicleAssessment(int vehicleAssessment) {
    if (vehicleAssessment >= 1 && vehicleAssessment <= 5) {
        this.vehicleAssessment = vehicleAssessment;
    } else {
        this.vehicleAssessment = 1;
        System.out.println("(vehicle Assessment considered as 1 because of invalid input)");
    }
}


    public int getVehicleAssessment() {
        return vehicleAssessment;
    }

    public void setIssues(boolean issues) {
        this.issues = issues;
    }

    public boolean isIssues() {
        return issues;
    }

    public void generateReport() {
        if (VIN != null && !VIN.isEmpty()) {
            System.out.println("*** CARSEER comprehensive Report ***");
            System.out.println("*** Cost 9.99 JOD ***");
            System.out.println(" *** Report date: 20/3/3023");
            System.out.println("General Information :");
            System.out.printf("\t%-20s%-10s\n", "Vehicle :", "VIN :");
            System.out.printf("\t%-20s%s\n", name + " " + year, VIN);

            System.out.println("Vehicle Assessment: " + vehicleAssessment + " out of 5");

            if (issues == false) {
                System.out.println("Vehicle has NO several issues such as Junks, Flood, Fire, Damage, and others \");");
            } else {
                System.out.println("Vehicle has several issues such as Junks, Flood, Fire, Damage, and others ");
            }
            System.out.println("End of Carseer report");
        } else {
            System.out.println("Cannot generate a report for an invalid VIN");
        }
    }
}
