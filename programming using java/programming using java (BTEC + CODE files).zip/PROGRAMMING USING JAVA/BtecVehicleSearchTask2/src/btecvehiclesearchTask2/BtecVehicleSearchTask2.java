package btecvehiclesearchTask2;

import java.util.Scanner;

public class BtecVehicleSearchTask2 {

    public static void main(String[] args) {
          Scanner scan = new Scanner(System.in);
        System.out.println("enter vehicle information in order");
        System.out.println("Name: ");
        String n = scan.nextLine();       
        System.out.println("year: ");
        int year1 = scan.nextInt();        
        scan.nextLine();
        System.out.println("VIN: (Make sure it's 17 characters, all uppercase with on space)");
        String vin = scan.nextLine();      
        System.out.println("vehicle assessment, (enter a number from 1 to 5)");
        int assess = scan.nextInt();
        System.out.println("Does this vehicle has issues such as Junks, Flood, Fire, Damage, etc (enter true or false)");
        boolean iss = scan.nextBoolean();
        CarReport o1 = new CarReport(n, year1, vin, assess, iss);
        o1.generateReport();
    }
}
