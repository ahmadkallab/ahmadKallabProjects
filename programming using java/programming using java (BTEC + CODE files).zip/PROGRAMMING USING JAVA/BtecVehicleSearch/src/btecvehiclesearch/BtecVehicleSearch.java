package btecvehiclesearch; // Package declaration

import java.util.ArrayList; // Importing required classes
import java.util.Scanner;

public class BtecVehicleSearch { // Class declaration

    public static ArrayList<String> vehicleNames = new ArrayList<>(); // ArrayList to store vehicle names
    public static ArrayList<Integer> vehicleYears = new ArrayList<>(); // ArrayList to store vehicle years
    public static Scanner scan = new Scanner(System.in); // Scanner object for user input

    public static void Run() { // Method to add vehicles
        boolean continueInput = true; // Variable to control loop
        
        while (continueInput) { // Loop to add vehicles
            System.out.println("Do you want to add vehicles? Enter 1 for Yes and 0 for No:"); // Prompt user to add vehicles
            int userDecision = scan.nextInt(); // Read user's decision
            scan.nextLine(); // Consume the remaining newline character
            
            if (userDecision == 1) { // Check user's decision
                System.out.println("*** Add vehicles ***"); // Prompt to add vehicles
                
                while (continueInput) { // Loop to add individual vehicles
                    System.out.println("Enter vehicle model then year separated by a single space (e.g. LEAF 2015):"); // Prompt for vehicle model and year
                    String[] inputParts = scan.nextLine().split(" "); // Read user input and split it by space
                    
                    if (inputParts.length >= 2) { // Check if the user entered both model and year
                        int year = Integer.parseInt(inputParts[1]); // Convert year to integer
                        vehicleNames.add(inputParts[0]); // Add vehicle model to list
                        vehicleYears.add(year); // Add vehicle year to list
                    } else {
                        System.out.println("Invalid input! Please enter a model name followed by a year separated by a single space."); // Error message for invalid input
                        continue; // Continue the loop
                    }
                    
                    while (true) { // Loop to check if the user wants to continue adding vehicles
                        System.out.println("Enter 1 to continue adding vehicles and 0 to stop:"); // Prompt to continue or stop
                        int continueDecision = scan.nextInt(); // Read user's decision
                        scan.nextLine(); // Consume the remaining newline character
                        
                        if (continueDecision == 1) { // Check user's decision
                            break; // Exit the loop to continue adding vehicles
                        } else if (continueDecision == 0) {
                            System.out.println("Vehicle addition stopped"); // Message to indicate that vehicle addition has stopped
                            continueInput = false; // Set the flag to false to stop adding vehicles
                            break; // Exit the loop
                        } else {
                            System.out.println("Invalid input! Please enter 1 to continue adding vehicles and 0 to stop."); // Error message for invalid input
                            continue; // Continue the loop
                        }
                    }
                }
            } else if (userDecision == 0) {
                System.out.println("*** Exit Program ***"); // Message to indicate program exit
                System.exit(0); // Exit the program
            } else {
                System.out.println("Invalid input! Please enter 1 to add vehicles and 0 to stop."); // Error message for invalid input
            }
        }
    }

    public static void main(String[] args) { // Main method
        while (true) { // Loop to start the program
            System.out.println("Do you want to start the program? (yes / no)"); // Prompt to start the program
            String userDecision = scan.nextLine().toLowerCase(); // Read user's decision and convert it to lowercase
            
            if (userDecision.equals("yes")) { // Check user's decision
                System.out.println("*** program starts***"); // Message to indicate program start
                Run(); // Call the Run method to add vehicles
                break; // Exit the loop
            } else if (userDecision.equals("no")) {
                System.out.println("*** Exit Program ***"); // Message to indicate program exit
                System.exit(0); // Exit the program
            } else {
                System.out.println("Invalid input! Please enter yes or no."); // Error message for invalid input
            }
        }
        
        boolean searchInput = true; // Variable to control loop
        
        while (searchInput) { // Loop for vehicle search
            System.out.println("*** Search ***"); // Message for search section
            System.out.println("Enter the year you would like to search:"); // Prompt for year input
            int searchYear = scan.nextInt(); // Read the year to search
            scan.nextLine(); // Consume the remaining newline character
            
            int index = searchForVehicleYear(searchYear); // Call method to search for the vehicle year
            
            if (index != -1) { // Check if the vehicle is found
                System.out.println("The vehicle found in " + searchYear + " is: " + vehicleNames.get(index)); // Print the vehicle found
                System.out.println("*** Search ends successfully ***"); // Message to indicate successful search
                searchInput = false; // Set the flag to false to exit the loop
            } else {
                System.out.println("There are no vehicles found in year " + searchYear + "."); // Message for no vehicle found
                System.out.println("*** Search ends successfully ***"); // Message to indicate successful search
                System.exit(0); // Exit the program
            }
        }
    }

    public static int searchForVehicleYear(int year) { // Method to search for vehicle year
        for (int i = 0; i < vehicleYears.size(); i++) { // Loop through vehicle years
            if (vehicleYears.get(i) == year) { // Check if year matches
                return i; // Return the index of the found vehicle
            }
        }
        return -1; // Return -1 if no vehicle is found
    }
}
